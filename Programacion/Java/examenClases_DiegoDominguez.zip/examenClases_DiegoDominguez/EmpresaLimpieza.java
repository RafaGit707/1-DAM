package examenClases_DiegoDominguez;

import java.time.LocalDate;
import java.util.Arrays;

import examenClases_DiegoDominguez.Empleados.Empleado;
import examenClases_DiegoDominguez.Vehiculos.Vehiculo;

public class EmpresaLimpieza {
    //Atributos
    private String nombre;
    private String cif;

    //Listado empleados
    static Empleado listaEmpleados[] = new Empleado[0];
    //Listado de vehiculos 
    static Vehiculo listaVehiculos[] = new Vehiculo[0];

    //Constructor
    public EmpresaLimpieza(String nombre, String cif){
        this.nombre = nombre;
        this.cif = cif;
    }
    
    //getters
        public String getNombre() {
            return nombre;
        }
        public String getCif() {
            return cif;
        }

    /* public void ordenarVehiculos(){
        Vehiculo nuevaLista[] = new Vehiculo[listaVehiculos.length];
        for(int i = 0; i < nuevaLista.length; i++){
            //obtiene el numero de meses y lo multiplica para obtener dias y le suma los días que lleva del mes, asi obtiene los dias totales
            int diasDesdeLavado = listaVehiculos[i].getFechaUltimaLimpieza().getMonthValue()*30 +
            (listaVehiculos[i].getFechaUltimaLimpieza().getDayOfMonth()); 

            if()
        }

    } */


    //
    public boolean contratarEmpleado(Empleado nuevoEmpleado){
        //Comprobar no existe
        boolean valido = true;
        int contador = 0;

        if(nuevoEmpleado.getSueldo() < 950){
            valido = false;
        }
        if(listaEmpleados.length > 0){
            while(contador < listaEmpleados.length && valido){
                if(listaEmpleados[contador].getCodigo() == nuevoEmpleado.getCodigo()){ //comprobar si existe el codigo
                    valido = false;
                }
                contador++;
            } //Fin bucle while    
        }

        if(valido){
            listaEmpleados = Arrays.copyOf(listaEmpleados, listaEmpleados.length+1);
            listaEmpleados[listaEmpleados.length-1] = nuevoEmpleado;
            return true;
        } else{
            return false;
        }
    }

    //
    public boolean despedirEmpleado(){
        if(listaEmpleados.length <= 0){
            return false;
        }
        Empleado nuevaLista[] = new Empleado[listaEmpleados.length-1];
        for(int i = 0; i < listaEmpleados.length; i++){
            nuevaLista[i] = listaEmpleados[i+1];
        }
        return true;
    }

    //
    public boolean insertarVehiculo(Vehiculo nuevoVehiculo){
        //Comprobar no existe
        boolean valido = true;
        int contador = 0;
        if(listaVehiculos.length > 0){
            while(contador < listaVehiculos.length && valido){
                if(listaVehiculos[contador].getMatricula() == nuevoVehiculo.getMatricula()){ //comprobar si existe la matricula
                    valido = false;
                }
                contador++;
            } //Fin bucle while
        }
     
        if(valido){
            listaVehiculos = Arrays.copyOf(listaVehiculos, listaVehiculos.length+1);
            listaVehiculos[listaVehiculos.length-1] = nuevoVehiculo;
            return true;
        } else{
            return false;
        }
     }

     //
    public void muestraTrabajadores(){
        for(int i = 0; i < listaEmpleados.length; i++){
            listaEmpleados[i].muestraInformacion();
        }
    }

    public void muestraInfoTrabajador(Empleado empleado){
        System.out.print(empleado.getCodigo() + " " + empleado.getNombre() + " " + 
        empleado.getApellido() + " " + empleado.getClass().getSimpleName() + " " + empleado.getSueldo() + " " );
        empleado.muestraInformacion();
        
    }

    public Vehiculo obtenerVehiculo(String matricula){
        for(int i = 0; i < listaVehiculos.length; i++){
            if(listaVehiculos[i].getMatricula().equals(matricula)){
                return listaVehiculos[i];
            }
        }
        return null;
    }

    public void muestraVehiculos(){
        for(int i = 0; i < listaVehiculos.length; i++){
            System.out.println(listaVehiculos[i].toString());
        }
    }

    public void limpiarVehiculo(){
        Vehiculo nuevaLista[] = new Vehiculo[listaVehiculos.length];
        Vehiculo vehiculoLimpiado = listaVehiculos[0];
        for(int i = 0; i < listaVehiculos.length-1; i++){
            nuevaLista[i] = listaVehiculos[i+1];
        }
        //Ponemos el vehiculo al final
        nuevaLista[nuevaLista.length-1] = vehiculoLimpiado;
        //Actualizamos su fecha de ultima limpieza
        nuevaLista[nuevaLista.length-1].setFechaUltimaLimpieza(LocalDate.now());
        //Actualizacion de la lista
        listaVehiculos = nuevaLista;
        System.out.println("Se ha limpiado el vehiculo: " + vehiculoLimpiado.getMatricula());
        
    }

    public String listadoTrabajadores(){
        String cadena = "";
        int peones = 0;
        int conductores = 0;
        int tecnicos = 0;
        for(int i = 0; i < listaEmpleados.length; i++){
            String tipo = listaEmpleados[i].getClass().getSimpleName();
            switch(tipo){
                case "Peon":
                    peones++;
                break;
                case "Conductor":
                    conductores++;
                break;
                case "Tecnico":
                    tecnicos++;
                break;
                default:
            }
        }
        cadena += "Peónes " + peones + "\nTécnicos: " + tecnicos + "\nConductores: " + conductores ;
        return cadena;
    }

    public Empleado buscarEmpleado(int codigo){
        for(int i = 0; i < listaEmpleados.length; i++){
            if(listaEmpleados[i].getCodigo() == (codigo)){
                return listaEmpleados[i];
            }
        }
        return null;
    }

}
