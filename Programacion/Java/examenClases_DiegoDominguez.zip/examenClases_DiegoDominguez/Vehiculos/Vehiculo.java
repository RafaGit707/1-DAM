package examenClases_DiegoDominguez.Vehiculos;

import java.time.LocalDate;

import examenClases_DiegoDominguez.Empleados.Conductor;

public class Vehiculo {
    //Atributos
    private String matricula;
    private int kms;
    private LocalDate fechaUltimaLimpieza;
    private Conductor conductorAsociado;

    //Constructor
    public Vehiculo(String matricula, int kms, LocalDate fechaUltimaLimpieza, Conductor conductorAsociado){
        this.matricula = matricula;
        this.kms = kms;
        this.fechaUltimaLimpieza = fechaUltimaLimpieza;
        this.conductorAsociado = conductorAsociado;
    }

    //Getters y setters
    public String getMatricula() {
        return matricula;
    }
    public int getKms() {
        return kms;
    }
    public LocalDate getFechaUltimaLimpieza() {
        return fechaUltimaLimpieza;
    }
    public void setFechaUltimaLimpieza(LocalDate fechaUltimaLimpieza) {
        this.fechaUltimaLimpieza = fechaUltimaLimpieza;
    }
    public Conductor getConductorAsociado() {
        return conductorAsociado;
    }

    
    @Override
    public String toString(){
        return this.matricula + ", kms: " + this.kms + ", fecha ultima limpieza: " + this.fechaUltimaLimpieza + ", conductor: " + this.conductorAsociado.getNombre();
    }
}
