package examenClases_DiegoDominguez;

public enum TallaRopa {

}
