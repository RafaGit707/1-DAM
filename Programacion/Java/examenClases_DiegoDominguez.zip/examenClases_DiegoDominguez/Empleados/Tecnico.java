package examenClases_DiegoDominguez.Empleados;

public class Tecnico extends Empleado{
    //Atributos
    private String nombreTituloOficial;
    private int yearTitulo;

    //Constructor
    public Tecnico(String nombre, String apellido, Turno turno, String nombreTitulo, int yearTitulo){
        super(nombre, apellido, turno);
        super.setSueldo(2000);
        this.nombreTituloOficial = nombreTitulo;
        this.yearTitulo = yearTitulo;        
    }
    //Getters y setters 
    public String getNombreTituloOficial() {
        return nombreTituloOficial;
    }
    public void setNombreTituloOficial(String nombreTituloOficial) {
        this.nombreTituloOficial = nombreTituloOficial;
    }
    public int getYearTitulo() {
        return yearTitulo;
    }
    public void setYearTitulo(int yearTitulo) {
        this.yearTitulo = yearTitulo;
    }

    //Metodos
    @Override
    public void muestraInformacion() {
        System.out.println(this.getCodigo() + " " + this.getNombre() + " " + this.getApellido() + " - " + this.getClass().getSimpleName() + " " + this.getSueldo() + 
        " Titulo: " + this.getNombreTituloOficial() + "(" + this.yearTitulo + ")");
    }
}
