package examenClases_DiegoDominguez.Empleados;

public abstract class Empleado {
    //Atributos
    private String nombre;
    private String apellido;
    private double sueldo;
    private int codigo;
    private Turno queTurno;

    public enum Turno {MAÑANA, TARDE, NOCHE};
    private static int acumuladorCodigo;
    
    //Constructor
    public Empleado(String nombre, String apellido, Turno turno){
        this.nombre = nombre;
        this.apellido = apellido;
        this.queTurno = turno;
        //Incremento del codigo
        acumuladorCodigo++;
        this.codigo = acumuladorCodigo;
    }
    public Empleado(String nombre, String apellido, double sueldo, Turno turno){
        this(nombre, apellido, turno);
        this.sueldo = sueldo;
    }

    //Metodos
    public abstract void muestraInformacion();

    //Getters y setters
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public double getSueldo() {
        return sueldo;
    }
    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public Turno getQueTurno() {
        return queTurno;
    }
    public void setQueTurno(Turno queTurno) {
        this.queTurno = queTurno;
    }

}
