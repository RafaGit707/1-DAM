package examenClases_DiegoDominguez.Empleados;

public class Peon extends Empleado{
    //Atributos
    private TallaRopa queTallaRopa;
    public enum TallaRopa {XS, S, L, XL, XXL};

    //Constructor
    public Peon(String nombre, String apellido, Turno turno, TallaRopa tallaRopa){
        super(nombre, apellido, turno);
        super.setSueldo(1000);
        this.queTallaRopa = tallaRopa;
    }
    //getters y setters
    public TallaRopa getQueTallaRopa() {
        return queTallaRopa;
    }
    public void setQueTallaRopa(TallaRopa queTallaRopa) {
        this.queTallaRopa = queTallaRopa;
    }
    
    //Metodos
    @Override
    public void muestraInformacion() {
        System.out.println(this.getCodigo() + " " + this.getNombre() + " " + this.getApellido() + " - " + this.getClass().getSimpleName() + " " + this.getSueldo() + 
        " Talla Ropa:" + this.getQueTallaRopa());
    }    
}
