package examenClases_DiegoDominguez.Empleados;

import java.time.LocalDate;

public class Conductor extends Empleado{
    //Atributos
    private LocalDate fechaCaducidadCarnetConducir;

    //Constructor
    public Conductor(String nombre, String apellido, Turno turno, LocalDate fechaCaducidad){
        super(nombre, apellido, turno);
        super.setSueldo(1500);
        this.fechaCaducidadCarnetConducir = fechaCaducidad;
    }
    //Getters y setters 
    public LocalDate getFechaCaducidadCarnetConducir() {
        return fechaCaducidadCarnetConducir;
    }

    //Metodos
    @Override
    public void muestraInformacion() {
        System.out.println(this.getCodigo() + " " + this.getNombre() + " " + this.getApellido() + " - " + getClass().getSimpleName() + " " + this.getSueldo() + 
        " Fecha caducidad carnet: " + this.fechaCaducidadCarnetConducir);
    }

}
