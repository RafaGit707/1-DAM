public class Tecnico extends Empleado {

    //subclase de Empleado

    private String nombreTituloOficial;
    private int yearTitulo;
    private int salario = 2000;

    public Tecnico(String nombre, String apellidos, String turno, String nombreTituloOficial, int yearTitulo) {
        super(nombre, apellidos, turno);
        this.nombreTituloOficial = nombreTituloOficial;
        this.yearTitulo = yearTitulo;
    }
    
    @Override
    public void mostrarInformacion() {
        System.out.println(codigoUnico + " " + nombre + " " + apellidos + " Técnico " + salario + " Título oficial: " + nombreTituloOficial + " Año de obtención del título: ");
    }
}
