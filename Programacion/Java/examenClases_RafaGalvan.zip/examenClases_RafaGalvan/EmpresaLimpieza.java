import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmpresaLimpieza {

    private String nombre;
    private String cif;
    private List<Empleado> listaTrabajadores;
    private List<Vehiculo> listaVehiculos;
    Vehiculo vehiculos;
    Empleado empleados;

    public EmpresaLimpieza() {
    }

    public EmpresaLimpieza(String nombre, String cif) {
        this.nombre = nombre;
        this.cif = cif;
        this.listaTrabajadores = new ArrayList<>();
        this.listaVehiculos = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCIF() {
        return cif;
    }

    public void setCIF(String cif) {
        this.cif = cif;
    }

    public boolean contratarEmpleado(Empleado empleado) {
        if (empleado.getSalario() < 950) {
            return false;
        } else {
            return this.listaTrabajadores.add(empleado);
        }
    }

    public boolean despedirEmpleado() {
        if (this.listaTrabajadores.isEmpty()) {
            return false;
        } else {
            this.listaTrabajadores.remove(Collections.min(this.listaTrabajadores, Comparator.comparing(Empleado::getCodigoUnico)));
            return true;
        }
    }

    public boolean insertarVehiculo(Vehiculo vehiculo) {
        if (listaVehiculos.stream().anyMatch(v -> v.getMatricula().equals(vehiculo.getMatricula()))) {
            return false;
        }
        return listaVehiculos.add(vehiculo);
    }

    public void muestraTrabajadores() {
        for (Empleado empleado : listaTrabajadores) {
            System.out.println(empleado.getCodigoUnico() + " " + empleado.getNombre() + " " + empleado.getApellidos() + " " + empleado.getClass().getSimpleName() + " " + empleado.getSalario() + " " + empleado.mostrarInformacion());
        }
    }

    public void mostrarInfoTrabajador(Empleado empleado) {
        System.out.println(empleado.getCodigoUnico() + " " + empleado.getNombre() + " " + empleado.getApellidos() + " " + empleado.getClass().getSimpleName() + " " + empleado.getSalario() + " " + empleado.mostrarInformacion());
    }

    public Vehiculo obtenerVehiculo(String matricula) {
        return vehiculos.stream().filter(v -> v.getMatricula().equals(matricula)).findFirst().orElse(null);
    }


    public void muestraVehiculos() {
        for (Vehiculo vehiculo : vehiculos) {
            System.out.println(vehiculo.getMatricula() + " " + vehiculo.getKms() + " " +
                    vehiculo.getFechaUltimaLimpieza() + " " + vehiculo.getConductorAsociado());
        }
    }

    public void limpiarVehiculo() {
        Vehiculo vehiculoLimpieza = Collections.min(vehiculos, Comparator.comparing(Vehiculo::getFechaUltimaLimpieza));
        vehiculoLimpieza.setFechaUltimaLimpieza(LocalDate.now());
        vehiculos.remove(vehiculoLimpieza);
        vehiculos.add(vehiculoLimpieza);
        System.out.println("Vehículo limpiado con matrícula: " + vehiculoLimpieza.getMatricula());
    }

    public String listadoTrabajadores() {
        long numPeones = empleados.stream().filter(e -> e instanceof Peon).count();
        long numConductores = empleados.stream().filter(e -> e instanceof Conductor).count();
        long numTecnicos = empleados.stream().filter(e -> e instanceof Tecnico).count();
    }


}
