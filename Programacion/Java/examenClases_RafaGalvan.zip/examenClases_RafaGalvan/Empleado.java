public abstract class Empleado {

    protected String nombre;
    protected String apellidos;
    protected int salario;
    protected int empleados;
    protected int codigoUnico;
    protected String turno;

    public abstract void mostrarInformacion();

    // Getters y setters
    public Empleado() {
    }

    public Empleado(String nombre, String apellidos, String turno) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.turno = turno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getSalario() {
        return salario;
    }

    public int getCodigoUnico() {
        return codigoUnico;
    }

    public void setCodigoUnico(int codigoUnico) {
        this.codigoUnico = codigoUnico;
    }

    public void setSalario(int salario) {
        if (salario >= 950) {
            this.salario = salario;
        } else {
            throw new IllegalArgumentException("El sueldo debe ser mayor o igual a 950 euros.");
        }
    }

    public Turno getTurno() {
        return turno;
    }

    public enum turno {
        MANANA,
        TARDE,
        NOCHE
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", salario=" + salario +
                ", idEmpleado=" + apellidos + //idEmpleado
                '}';
    }



}
