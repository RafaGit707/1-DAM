import java.time.LocalDate;

public class Conductor extends Empleado {

    //subclase de Empleado

    private LocalDate fechaCaducidadCarnet;
    private int salario = 1500;

    public Conductor(String nombre, String apellidos, String turno, LocalDate fechaCaducidadCarnet) {
        super(nombre, apellidos, turno);
        this.fechaCaducidadCarnet = fechaCaducidadCarnet;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println(codigoUnico + " " + nombre + " " + apellidos + " Conductor " + salario + " Fecha de caducidad del carnet de conducir: " + fechaCaducidadCarnet);
    }

    public LocalDate getFechaCaducidadCarnet() {
        return fechaCaducidadCarnet;
    }
    
}
