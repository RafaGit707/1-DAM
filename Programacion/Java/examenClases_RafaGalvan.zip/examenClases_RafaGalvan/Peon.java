public class Peon extends Empleado {
    
    //subclase de Empleado

    private String tallaRopa;
    private int salario = 1000;

    public Peon(String nombre, String apellidos, String turno, String tallaRopa) {
        super(nombre, apellidos, turno);
        this.tallaRopa = tallaRopa;
    }

    public String getTallaRopa() {
        return tallaRopa;
    }

    public void setTallaRopa(String tallaRopa) {
        this.tallaRopa = tallaRopa;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println(codigoUnico + " " + nombre + " " + apellidos + " Peón " + salario + " Talla de ropa: " + tallaRopa);
    }

}
