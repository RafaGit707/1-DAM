import java.time.LocalDate;

public class Vehiculo {
    
    private String matricula;
    private int kms;
    private LocalDate fechaUltimaLimpieza;
    private Empleado conductorAsociado;

    public Vehiculo(String matricula, int kms, LocalDate fechaUltimaLimpieza, Empleado conductorAsociado) {
        this.matricula = matricula;
        this.kms = kms;
        this.fechaUltimaLimpieza = fechaUltimaLimpieza;
        this.conductorAsociado = conductorAsociado;
    }

    public String getMatricula() {
        return matricula;
    }

    public int getKms() {
        return kms;
    }

    public void setKms(int kms) {
        this.kms = kms;
    }

    public LocalDate getFechaUltimaLimpieza() {
        return fechaUltimaLimpieza;
    }

    public void setFechaUltimaLimpieza(LocalDate fechaUltimaLimpieza) {
        this.fechaUltimaLimpieza = fechaUltimaLimpieza;
    }

    public Empleado getConductorAsociado() {
        return conductorAsociado;
    }

    public void setConductorAsociado(Empleado conductorAsociado) {
        this.conductorAsociado = conductorAsociado;
    }

    @Override
    public String toString() {
        return "Matricula: " + matricula +
                ", Kms: " + kms +
                ", Fecha Ultima Limpieza: " + fechaUltimaLimpieza +
                ", Conductor Asociado: " + (conductorAsociado != null ? conductorAsociado.getNombre() : "Ninguno");
    }

}
